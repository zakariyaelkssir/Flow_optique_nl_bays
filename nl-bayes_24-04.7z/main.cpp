/*
 * Copyright (c) 2013, Marc Lebrun <marc.lebrun.ik@gmail.com>
 * All rights reserved.
 *
 * This program is free software: you can use, modify and/or
 * redistribute it under the terms of the GNU General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later
 * version. You should have received a copy of this license along
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>

#include <string>
#include <sstream>
#include "Utilities/Utilities.h"
#include "NlBayes/NlBayes.h"
#include "Utilities/LibImages.h"
#include "iio.h"
#include "tvl1flow_lib.c"

#define PAR_DEFAULT_OUTFLOW "flow.flo"
#define PAR_DEFAULT_NPROC   0
#define PAR_DEFAULT_TAU     0.25
#define PAR_DEFAULT_LAMBDA  0.15
#define PAR_DEFAULT_THETA   0.3
#define PAR_DEFAULT_NSCALES 100
#define PAR_DEFAULT_ZFACTOR 0.5
#define PAR_DEFAULT_NWARPS  5
#define PAR_DEFAULT_EPSILON 0.01
#define PAR_DEFAULT_VERBOSE 0

using namespace std;

/**
 * @file   main.cpp
 * @brief  Main executable file
 *
 *
 *
 * @author MARC LEBRUN  <marc.lebrun.ik@gmail.com>
 **/

int main(int argc, char **argv)
{
    //! Check if there is the right call for the algorithm
	if (argc < 15) {
		cout << "usage: NL_Bayes image sigma noisy denoised basic difference \
		bias basic_bias diff_bias useArea1 useArea2 computeBias" << endl;
		return EXIT_FAILURE;
	}

    //! Variables initialization
	const float sigma   = atof(argv[2]);
	const bool doBias   = (bool) atof(argv[12]);
	const bool useArea1 = (bool) atof(argv[10]);
	const bool useArea2 = (bool) atof(argv[11]);
	const bool verbose  = true;
    const int nB_frame  = 3;
	//! Declarations
	vector<float> im,im1,im2, imNoisy,imNoisy1,imNoisy2, imBasic,imBasic1, imFinal, imDiff,immouv,immouv1,im_mov_resultat,im_mov_resultat1;
	vector<float> imBias, imBasicBias, imDiffBias;
	ImageSize imSize;
    vector<vector<float>> im_reel(nB_frame),im_Noisy(nB_frame),im_Basic(nB_frame),im_Final(nB_frame),im_Diff(nB_frame);
    //! Load image
	if(loadImage(argv[1], im, imSize, verbose) != EXIT_SUCCESS) {
        return EXIT_FAILURE;
	}
    cout<<imSize.whc<<endl;
    if(loadImage(argv[13], im1, imSize, verbose) != EXIT_SUCCESS) {
        return EXIT_FAILURE;
	}
    cout<<imSize.whc<<endl;
    if(loadImage(argv[14], im2, imSize, verbose) != EXIT_SUCCESS) {
        return EXIT_FAILURE;
	}
    cout<<imSize.whc<<endl;
    // load images 
    for (int i=0;i<nB_frame;i++){
      string location = "images/frame0"+ to_string(i);
      if(loadImage(&location[0], im_reel[i], imSize, verbose) != EXIT_SUCCESS) {
      return EXIT_FAILURE;
	} 
    addNoise(im_reel[i], im_Noisy[i], sigma, verbose);
    } 
	//! Add noise
    addNoise(im, imNoisy, sigma, verbose);
    addNoise(im1, imNoisy1, sigma, verbose);
    addNoise(im2, imNoisy2, sigma, verbose);
    //! Denoising
    // calcule mouvement 
   // for(int c=0;i<imSize.nChannels;c++){
       immouv.resize(imSize.whc);
       immouv1.resize(imSize.whc);
       im_mov_resultat.resize(imSize.whc);
       im_mov_resultat1.resize(imSize.whc);
       
   /*     for(unsigned i=0;i<imSize.whc;i++){
            immouv[i]=imNoisy1[i]-imNoisy[i];
            immouv1[i]=imNoisy2[i]-imNoisy[i];;
            
    }*/
    // test calcule flow optique 
    // frame1 -> frame 2 

    float *u = (float*)xmalloc(2 * imSize.height * imSize.width * sizeof*u);
	float *v = u + imSize.height * imSize.width;

    float **u_images = (float**)malloc((nB_frame-1)*sizeof(float*));
    float **v_images = (float**)malloc((nB_frame-1)*sizeof(float*));

    for(int i =0;i<nB_frame-1;i++){
    u_images[i] = (float*)xmalloc(2 * imSize.height * imSize.width * sizeof*u);
	v_images[i] = u + imSize.height * imSize.width;
    }

   // int   nproc   = PAR_DEFAULT_NPROC;   
	float tau     = PAR_DEFAULT_TAU;    
	float lambda  = PAR_DEFAULT_LAMBDA;  
	float theta   = PAR_DEFAULT_THETA;   
	int   nscales = PAR_DEFAULT_NSCALES;
	float zfactor = PAR_DEFAULT_ZFACTOR; 
	int   nwarps  = PAR_DEFAULT_NWARPS;  
	float epsilon = PAR_DEFAULT_EPSILON; 
    
    Dual_TVL1_optic_flow_multiscale(&imNoisy1[0],&imNoisy[0],u,v,imSize.width,imSize.height,tau, lambda, theta,
				nscales, zfactor, nwarps, epsilon, false);
    // calcule le center 
    int center_image = (int)nB_frame/2;
    // nombre d'images a droit et a gauche
    int nombre_image = (nB_frame-1)/2; 
   for (int i=1;i<=nombre_image;i++){           
    Dual_TVL1_optic_flow_multiscale(&im_Noisy[center_image+i][0],&im_Noisy[center_image][0],u_images[0],v_images[0],imSize.width,imSize.height,tau, lambda, theta,
				nscales, zfactor, nwarps, epsilon, false);
                 
    Dual_TVL1_optic_flow_multiscale(&im_Noisy[center_image][0],&im_Noisy[center_image-i][0],u_images[1],v_images[1],imSize.width,imSize.height,tau, lambda, theta,
				nscales, zfactor, nwarps, epsilon, false);
   }

    cout<<"imSize : "<<imSize.whc;
    
    if (verbose) {
        cout << endl << "Applying NL-Bayes to the noisy image :" << endl;
    }
    if (runNlBayes(imNoisy, imBasic, imFinal, imSize, useArea1, useArea2, sigma, verbose,imNoisy1,u,v,imBasic1,nB_frame,im_Noisy,im_Basic,im_Final,u_images,v_images)
        != EXIT_SUCCESS) {
            cout<<"im here";
        return EXIT_FAILURE;
    }
    if (verbose) {
        cout << endl;
    }
 /*  for(unsigned i=0;i<imSize.whc;i++){
            im_mov_resultat[i]=imFinal[i]+immouv[i];
            im_mov_resultat1[i]=imFinal[i]+immouv1[i];
            
    }*/

		
		for (unsigned j=0;j<imSize.height;j++){
			for(unsigned i=0;i<imSize.width;i++){
				float p[2] = {i + u[j*imSize.width + i],j + v[j * imSize.width + i]};
			//	printf("%f , %f \t",p[0],p[1]);
			//int a = p[0]*nx+p[1];
			//printf("%d\t",a);
			float value = bicubic_interpolation_at(&imFinal[0],p[0],p[1],imSize.width,imSize.width,false);
			im_mov_resultat[j * imSize.width + i] = value;
			}
        }
    
        float *u1= (float*)xmalloc(2 * imSize.height * imSize.width * sizeof*u1);
	    float *v1= u1 + imSize.height * imSize.width;
    Dual_TVL1_optic_flow_multiscale(&imNoisy2[0],&imNoisy[0],u1,v1,imSize.width,imSize.height,tau, lambda, theta,
				nscales, zfactor, nwarps, epsilon, false);

		for (unsigned j=0;j<imSize.height;j++){
			for(unsigned i=0;i<imSize.width;i++){
            float p[2] = {i + u1[j*imSize.width + i],j + v1[j * imSize.width + i]};
			//	printf("%f , %f \t",p[0],p[1]);
			//int a = p[0]*nx+p[1];
			//printf("%d\t",a);
			float value = bicubic_interpolation_at(&imFinal[0],p[0],p[1],imSize.width,imSize.width,false);
			im_mov_resultat1[j * imSize.width + i] = value;
			}
        }
    //! Bias denoising
	if (doBias) {
        if (verbose) {
            cout << "Applying NL-Bayes to the original image :" << endl;
        }
        if (runNlBayes(im, imBasicBias, imBias, imSize, useArea1, useArea2, sigma, verbose,imNoisy1,u,v,imBasic1,nB_frame,im_Noisy,im_Basic,im_Final,u_images,v_images)
             != EXIT_SUCCESS) {
             return EXIT_FAILURE;
        }
        if (verbose) {
            cout << endl;
        }
	}

	//! Compute PSNR and RMSE
    float psnr, rmse, psnrBasic, rmseBasic;
    computePsnr(im, imBasic, psnrBasic, rmseBasic, "imBasic", verbose);
    computePsnr(im, imFinal, psnr, rmse, "imFinal", verbose);

    float psnrBias, psnrBiasBasic, rmseBias, rmseBiasBasic;
    if (doBias) {
        computePsnr(im, imBasicBias, psnrBiasBasic, rmseBiasBasic, "imBiasBasic", verbose);
        computePsnr(im, imBias, psnrBias, rmseBias, "imBiasFinal", verbose);
    }

    //! writing measures
    writingMeasures("measures.txt", sigma, psnrBasic, rmseBasic, true, "_basic");
    writingMeasures("measures.txt", sigma, psnr, rmse, false, "      ");
    if (doBias) {
        writingMeasures("measures.txt", sigma, psnrBiasBasic, rmseBiasBasic, false, "_bias_basic");
        writingMeasures("measures.txt", sigma, psnrBias, rmseBias, false, "_bias      ");
    }

    //! Compute Difference
	if (computeDiff(im, imFinal, imDiff, sigma, 0.f, 255.f, verbose) != EXIT_SUCCESS) {
        return EXIT_FAILURE;
	}
	if (doBias) {
        if (computeDiff(im, imBias, imDiffBias, sigma, 0.f, 255.f, verbose) != EXIT_SUCCESS) {
            return EXIT_FAILURE;
        }
	}

    //! save noisy, denoised and differences images
	if (verbose) {
	    cout << "Save images...";
	}
	if (saveImage(argv[3], imNoisy, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}

	if (saveImage("result_estimation_next_frame/frame01", imFinal, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
    if (saveImage("result_estimation_block_matching/frame01", imFinal, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}

    if (saveImage("Basic", imBasic, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
        return EXIT_FAILURE;
    }
    if (saveImage("result_estimation_block_matching/frame02", imBasic1, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
        return EXIT_FAILURE;
    }
    if (saveImage(argv[6], imDiff, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
		return EXIT_FAILURE;
    }
    if (saveImage("result_estimation_next_frame/frame02", im_mov_resultat, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
    if (saveImage("result_estimation_next_frame/frame00", im_mov_resultat1, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}

    for(int i = 0 ;i<nB_frame ; i++){
        string location = "resultat_finale/frame0"+ to_string(i);
     if (saveImage(&location[0], im_Basic[i], imSize, 0.f, 255.f) != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
    }
    if (doBias) {
        if (saveImage(argv[7], imBias, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
            return EXIT_FAILURE;
        }

        if (saveImage(argv[8], imBasicBias, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
            return EXIT_FAILURE;
        }

        if (saveImage(argv[9], imDiffBias, imSize, 0.f, 255.f) != EXIT_SUCCESS) {
            return EXIT_FAILURE;
        }
    }
    if (verbose) {
        cout << "done." << endl;
    }

	return EXIT_SUCCESS;
}
