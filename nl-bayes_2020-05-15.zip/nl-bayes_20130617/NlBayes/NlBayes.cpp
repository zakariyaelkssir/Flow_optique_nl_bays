/*
 * Copyright (c) 2013, Marc Lebrun <marc.lebrun.ik@gmail.com>
 * All rights reserved.
 *
 * This program is free software: you can use, modify and/or
 * redistribute it under the terms of the GNU General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later
 * version. You should have received a copy of this license along
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @file NlBayes.cpp
 * @brief NL-Bayes denoising functions
 *
 * @author Marc Lebrun <marc.lebrun.ik@gmail.com>
 **/

#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <math.h>

#include "NlBayes.h"
#include "LibMatrix.h"
#include "../Utilities/LibImages.h"
#include "../Utilities/Utilities.h"
//#include "../iio.h"
#include "bicubic_interpolation.c"

#define PAR_DEFAULT_OUTFLOW "flow.flo"
#define PAR_DEFAULT_NPROC   0
#define PAR_DEFAULT_TAU     0.25
#define PAR_DEFAULT_LAMBDA  0.15
#define PAR_DEFAULT_THETA   0.3
#define PAR_DEFAULT_NSCALES 100
#define PAR_DEFAULT_ZFACTOR 0.5
#define PAR_DEFAULT_NWARPS  5
#define PAR_DEFAULT_EPSILON 0.01
#define PAR_DEFAULT_VERBOSE 0
#ifdef _OPENMP
#include <omp.h>
#endif

using namespace std;

/**
 * @brief Initialize Parameters of the NL-Bayes algorithm.
 *
 * @param o_paramStep1 : will contain the nlbParams for the first step of the algorithm;
 * @param o_paramStep2 : will contain the nlbParams for the second step of the algorithm;
 * @param p_sigma : standard deviation of the noise;
 * @param p_imSize: size of the image;
 * @param p_useArea1 : if true, use the homogeneous area trick for the first step;
 * @param p_useArea2 : if true, use the homogeneous area trick for the second step;
 * @param p_verbose : if true, print some informations.
 *
 * @return none.
 **/
void initializeNlbParameters(
	nlbParams &o_paramStep1
,	nlbParams &o_paramStep2
,   const float p_sigma
,	const ImageSize &p_imSize
,	const bool p_useArea1
,   const bool p_useArea2
,   const bool p_verbose
){
	//! Standard deviation of the noise
	o_paramStep1.sigma = p_sigma;
	o_paramStep2.sigma = p_sigma;

	//! Size of patches
	if (p_imSize.nChannels == 1) {
		o_paramStep1.sizePatch = (p_sigma < 30.f ? 5 : 7);
		o_paramStep2.sizePatch = 5;
	}
	else {
		o_paramStep1.sizePatch = (p_sigma < 20.f ? 3 :
                                 (p_sigma < 50.f ? 5 : 7));
        o_paramStep2.sizePatch = (p_sigma < 50.f ? 3 :
                                 (p_sigma < 70.f ? 5 : 7));
	}

	//! Number of similar patches
	if (p_imSize.nChannels == 1) {
		o_paramStep1.nSimilarPatches =	(p_sigma < 10.f ? 35 :
										(p_sigma < 30.f ? 45 :
										(p_sigma < 80.f ? 90 : 100)));
		o_paramStep2.nSimilarPatches =	(p_sigma < 20.f ? 15 :
										(p_sigma < 40.f ? 25 :
										(p_sigma < 80.f ? 30 : 45)));
	}
	else {
		o_paramStep1.nSimilarPatches = o_paramStep1.sizePatch * o_paramStep1.sizePatch * 3;
		o_paramStep2.nSimilarPatches = o_paramStep2.sizePatch * o_paramStep2.sizePatch * 3;
	}

	//! Offset: step between two similar patches
	o_paramStep1.offSet = o_paramStep1.sizePatch / 2;
	o_paramStep2.offSet = o_paramStep2.sizePatch / 2;

	//! Use the homogeneous area detection trick
	o_paramStep1.useHomogeneousArea = p_useArea1;
	o_paramStep2.useHomogeneousArea = p_useArea2;

	//! Size of the search window around the reference patch (must be odd)
	o_paramStep1.sizeSearchWindow = o_paramStep1.nSimilarPatches / 2;
	if (o_paramStep1.sizeSearchWindow % 2 == 0) {
		o_paramStep1.sizeSearchWindow++;
	}
	o_paramStep2.sizeSearchWindow = o_paramStep2.nSimilarPatches / 2;
	if (o_paramStep2.sizeSearchWindow % 2 == 0) {
		o_paramStep2.sizeSearchWindow++;
	}

	//! Size of boundaries used during the sub division
	o_paramStep1.boundary = int(1.5f * float(o_paramStep1.sizeSearchWindow));
	o_paramStep2.boundary = int(1.5f * float(o_paramStep2.sizeSearchWindow));

	//! Parameter used to determine if an area is homogeneous
	o_paramStep1.gamma = 1.05f;
	o_paramStep2.gamma = 1.05f;

	//! Parameter used to estimate the covariance matrix
	if (p_imSize.nChannels == 1) {
		o_paramStep1.beta = (p_sigma < 15.f ? 1.1f :
                            (p_sigma < 70.f ? 1.f : 0.9f));
		o_paramStep2.beta = (p_sigma < 15.f ? 1.1f :
                            (p_sigma < 35.f ? 1.f : 0.9f));
	}
	else {
		o_paramStep1.beta = 1.f;
		o_paramStep2.beta = (p_sigma < 50.f ? 1.2f : 1.f);
	}

	//! Parameter used to determine similar patches
	o_paramStep2.tau = 16.f * o_paramStep2.sizePatch * o_paramStep2.sizePatch * p_imSize.nChannels;

	//! Print information?
	o_paramStep1.verbose = p_verbose;
	o_paramStep2.verbose = p_verbose;

	//! Is first step?
	o_paramStep1.isFirstStep = true;
	o_paramStep2.isFirstStep = false;

	//! Boost the paste trick
	o_paramStep1.doPasteBoost = true;
	o_paramStep2.doPasteBoost = true;
}

/**
 * @brief Main function to process the whole NL-Bayes algorithm.
 *
 * @param i_imNoisy: contains the noisy image;
 * @param o_imBasic: will contain the basic estimate image after the first step;
 * @param o_imFinal: will contain the final denoised image after the second step;
 * @param p_imSize: size of the image;
 * @param p_useArea1 : if true, use the homogeneous area trick for the first step;
 * @param p_useArea2 : if true, use the homogeneous area trick for the second step;
 * @param p_sigma : standard deviation of the noise;
 * @param p_verbose : if true, print some informations.
 *
 * @return EXIT_FAILURE if something wrong happens during the whole process.
 **/
int runNlBayes(
	std::vector<float> const& i_imNoisy
,   std::vector<float> &o_imBasic
,	std::vector<float> &o_imFinal
,	const ImageSize &p_imSize
,	const bool p_useArea1
,	const bool p_useArea2
,	const float p_sigma
,   const bool p_verbose
,   std::vector<float> const& i_imNoisy1
,   float *u
,   float *v
,   std::vector<float> &o_imBasic1
,   const int nB_frame
,   std::vector<std::vector<float>> const& i_im_Noisy
,   std::vector<std::vector<float>> & i_im_Basic
,   std::vector<std::vector<float>> & i_im_Final
,   float **v_images
,   float **u_images
){
	//! Only 1, 3 or 4-channels images can be processed.
	const unsigned chnls = p_imSize.nChannels;
	if (! (chnls == 1 || chnls == 3 || chnls == 4)) {
		cout << "Wrong number of channels. Must be 1 or 3!!" << endl;
		return EXIT_FAILURE;
	}
	//! Number of available cores
	unsigned nbThreads = 1;
#ifdef _OPENMP
    nbThreads = omp_get_max_threads();
    if (p_verbose) {
        cout << "Open MP is used" << endl;
    }
#endif

	//! Initialization
	o_imBasic.resize(i_imNoisy.size());
	o_imBasic1.resize(i_imNoisy1.size());

	for(int i=0 ;i<nB_frame;i++){
		i_im_Basic[i].resize(i_im_Noisy[i].size());
		i_im_Final[i].resize(i_im_Noisy[i].size());
	}
	
	o_imFinal.resize(i_imNoisy.size());

	//! Parameters Initialization
	nlbParams paramStep1, paramStep2;
	initializeNlbParameters(paramStep1, paramStep2, p_sigma, p_imSize, p_useArea1, p_useArea2,
                         p_verbose);

	//! Step 1
	if (paramStep1.verbose) {
		cout << "1st Step...";
	}

	//! RGB to YUV
	vector<float> imNoisy = i_imNoisy;
	vector<float> imNoisy1 = i_imNoisy1;

	vector<vector<float>> im_Noisy = i_im_Noisy;

	for(int i = 0;i<nB_frame;i++){
		transformColorSpace(im_Noisy[i], p_imSize, true);
	}
	transformColorSpace(imNoisy, p_imSize, true);
	transformColorSpace(imNoisy1, p_imSize, true);
	//! Divide the noisy image into sub-images in order to easier parallelize the process
	const unsigned nbParts = 2 * nbThreads;
	vector<vector<float> > imNoisySub(nbParts), imBasicSub(nbParts), imFinalSub(nbParts);
	vector<vector<float> > imNoisySub1(nbParts), imBasicSub1(nbParts), imFinalSub1(nbParts);
	ImageSize imSizeSub,imSizeSub1;


	vector<vector<float> > imBasicSub25(nbParts);


	//vector<vector<vector<float>>> im_NoisySub(nB_frame, vector<vector<float> > (nbParts));
	vector<vector<vector<float>>> im_NoisySub(nB_frame, vector<vector<float> > (nbParts)), im_BasicSub(nB_frame, vector<vector<float> > (nbParts)), im_FinalSub(nB_frame, vector<vector<float> > (nbParts));


	vector<ImageSize> im_SizeSub(nB_frame);
	if (subDivide(imNoisy, imNoisySub, p_imSize, imSizeSub, paramStep1.boundary, nbParts)
		!= EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
	if (subDivide(imNoisy1, imNoisySub1, p_imSize, imSizeSub1, paramStep1.boundary, nbParts)
		!= EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}

	for(int i=0;i<nB_frame;i++){
		if (subDivide(im_Noisy[i], im_NoisySub[i], p_imSize, im_SizeSub[i], paramStep1.boundary, nbParts)
		!= EXIT_SUCCESS) {
		
	}
	}
	//! Process all sub-images
#ifdef _OPENMP
#pragma omp parallel for schedule(dynamic, nbParts/nbThreads) \
            shared(imNoisySub, imBasicSub, imFinalSub, imSizeSub) \
		firstprivate (paramStep1)
#endif
	for (int n = 0; n < (int) nbParts; n++) {
		vector<vector<float>>  im__NoisySub(nB_frame);
		vector<vector<float>>  im__BasicSub(nB_frame);
		vector<vector<float>>  im__FinalSub(nB_frame);
		for(int i =0 ; i< nB_frame;i++){
				im__NoisySub[i] = im_NoisySub[i][n];
				im__FinalSub[i] = im_FinalSub[i][n];
		}
		
	    processNlBayes(imNoisySub[n], imBasicSub[n], imFinalSub[n], imSizeSub, paramStep1,imNoisySub1[n], imBasicSub1[n], imFinalSub1[n],u,v,im__NoisySub,im_SizeSub,nB_frame,im__FinalSub,n,im_BasicSub,v_images,u_images);
	}
	
	//! Get the basic estimate
	if (subBuild(o_imBasic, imBasicSub, p_imSize, imSizeSub, paramStep1.boundary)
		!= EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
	if (subBuild(o_imBasic1, im_BasicSub[1], p_imSize, imSizeSub1, paramStep1.boundary)
		!= EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
	for(int i = 0;i<nB_frame ; i++){
		if (subBuild(i_im_Basic[i], im_BasicSub[i], p_imSize, imSizeSub1, paramStep1.boundary)
		!= EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
	}

	//! YUV to RGB
	transformColorSpace(o_imBasic, p_imSize, false);
	transformColorSpace(o_imBasic1, p_imSize, false);

	if (paramStep1.verbose) {
		cout << "done." << endl;
	}

	//! 2nd Step
	if (paramStep2.verbose) {
		cout << "2nd Step...";
	}

	//! Divide the noisy and basic images into sub-images in order to easier parallelize the process
	if (subDivide(i_imNoisy, imNoisySub, p_imSize, imSizeSub, paramStep2.boundary, nbParts)
        != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
	if (subDivide(o_imBasic, imBasicSub, p_imSize, imSizeSub, paramStep2.boundary, nbParts)
		!= EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}

	//! Process all sub-images
#ifdef _OPENMP
#pragma omp parallel for schedule(dynamic, nbParts/nbThreads) \
            shared(imNoisySub, imBasicSub, imFinalSub) \
		firstprivate (paramStep2)
#endif
	for (int n = 0; n < (int) nbParts; n++) {
		vector<vector<float>> im__NoisySub(nB_frame);
		vector<vector<float>> im__FinalSub(nB_frame);
		processNlBayes(imNoisySub[n], imBasicSub[n], imFinalSub[n], imSizeSub, paramStep2,imNoisySub1[n], imBasicSub1[n], imFinalSub1[n],u,v,im__NoisySub,im_SizeSub,nB_frame,im__FinalSub,n,im_BasicSub,v_images,u_images);
	}

	//! Get the final result
	if (subBuild(o_imFinal, imFinalSub, p_imSize, imSizeSub, paramStep2.boundary)
		!= EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
	if (paramStep2.verbose) {
		cout << "done." << endl << endl;
	}

	return EXIT_SUCCESS;
}

/**
 * @brief Generic step of the NL-Bayes denoising (could be the first or the second).
 *
 * @param i_imNoisy: contains the noisy image;
 * @param io_imBasic: will contain the denoised image after the first step (basic estimation);
 * @param o_imFinal: will contain the denoised image after the second step;
 * @param p_imSize: size of i_imNoisy;
 * @param p_params: see nlbParams.
 *
 * @return none.
 **/
void processNlBayes(
	std::vector<float> const& i_imNoisy
,	std::vector<float> &io_imBasic
,	std::vector<float> &o_imFinal
,	const ImageSize &p_imSize
,	nlbParams &p_params
,	std::vector<float> const& i_imNoisy1
,	std::vector<float> &io_imBasic1
,	std::vector<float> &o_imFinal1
,   float *u
,   float *v
, 	std::vector<std::vector<float>> const& i__imNoisy
,   const std::vector<ImageSize> &im_SizeSub
,   const int nB_frame
, 	std::vector<std::vector<float>> &o_FinalSub
,   int n
,   std::vector<std::vector<std::vector<float>>> &io__imBasic
,   float **v_images
,   float **u_images
){
	//! Parameters initialization
	const unsigned sW		= p_params.sizeSearchWindow;
	const unsigned sP		= p_params.sizePatch;
	const unsigned sP2		= sP * sP;
	const unsigned sPC		= sP2 * p_imSize.nChannels;
	const unsigned nSP		= p_params.nSimilarPatches;
	unsigned nInverseFailed	= 0;
	const float threshold	= p_params.sigma * p_params.sigma * p_params.gamma *
                                (p_params.isFirstStep ? p_imSize.nChannels : 1.f);

	//! Allocate Sizes
	if (p_params.isFirstStep) {
		io_imBasic.resize(p_imSize.whc);
		io_imBasic1.resize(p_imSize.whc);
	for(int i =0 ;i<nB_frame;i++){
		io__imBasic[i][n].resize(p_imSize.whc);
	}
	}
	o_imFinal.resize(p_imSize.whc);
	o_imFinal1.resize(p_imSize.whc);
	for(int i=0;i<nB_frame;i++){
		o_FinalSub[i].resize(p_imSize.whc);
	}

	//! Used matrices during Bayes' estimate
	vector<vector<float>> group3d(p_imSize.nChannels, vector<float> (nSP * sP2)),group3d_frame2(p_imSize.nChannels, vector<float> (nSP * sP2));
	vector<vector<vector<float>>> group4d(nB_frame,vector<vector<float>>(p_imSize.nChannels,vector<float> (nSP * sP2)));
	//vector<vector<vector<float>>> im_NoisySub(nB_frame, vector<vector<float>> (nbParts))
	vector<float> group3dNoisy(sW * sW * sPC), group3dBasic(sW * sW * sPC);
	vector<vector<float>> group4dNoisy(nB_frame, vector<float> (sW * sW * sPC));
	vector<vector<float>> group4dBasic(nB_frame, vector<float> (sW * sW * sPC));

	

	vector<unsigned> index(p_params.isFirstStep ? nSP : sW * sW);
	vector<unsigned> index1(p_params.isFirstStep ? nSP : sW * sW);

	vector<vector<unsigned>> index_4d(nB_frame, vector<unsigned> (p_params.isFirstStep ? nSP : sW * sW));

	matParams mat;
	mat.group3dTranspose.resize(p_params.isFirstStep ? nSP * sP2 : sW * sW * sPC);
	mat.tmpMat          .resize(p_params.isFirstStep ? sP2 * sP2 : sPC * sPC);
	mat.baricenter      .resize(p_params.isFirstStep ? sP2 : sPC);
	mat.covMat          .resize(p_params.isFirstStep ? sP2 * sP2 : sPC * sPC);
	mat.covMatTmp       .resize(p_params.isFirstStep ? sP2 * sP2 : sPC * sPC);

	//! ponderation: weight sum per pixel
	vector<float> weight(i_imNoisy.size(), 0.f);
    vector<float> weight1(i_imNoisy1.size(), 0.f);

	vector<vector<float>> weight_4d(nB_frame, vector<float> (i_imNoisy.size(), 0.f));


	//! Mask: non-already processed patches
	vector<bool> mask(p_imSize.wh, false);
	//! Only pixels of the center of the image must be processed (not the boundaries)
	for (unsigned i = sW; i < p_imSize.height - sW; i++) {
		for (unsigned j = sW; j < p_imSize.width - sW; j++) {
			mask[i * p_imSize.width + j] = true;
		}
	}
	 
	for (unsigned ij = 0; ij < p_imSize.wh; ij += p_params.offSet) {
		//! Only non-seen patches are processed
		if (mask[ij]) {
			//! Search for similar patches around the reference one
			unsigned nSimP = p_params.nSimilarPatches;
			if (p_params.isFirstStep) {
				estimateSimilarPatchesStep1(i_imNoisy, group3d, index, ij, p_imSize, p_params,group3d_frame2,u,v,i_imNoisy1,index1,i__imNoisy,group4d,index_4d,nB_frame,u_images,v_images);
			}
			else {
				nSimP = estimateSimilarPatchesStep2(i_imNoisy, io_imBasic, group3dNoisy,
					group3dBasic, index, ij, p_imSize, p_params);
			}

			//! Initialization
			bool doBayesEstimate = true;
			//bool doBayesEstimate1 = true;

			//! If we use the homogeneous area trick
			if (p_params.useHomogeneousArea) {
				if (p_params.isFirstStep) {
					doBayesEstimate = !computeHomogeneousAreaStep1(group3d, sP, nSP,
						threshold, p_imSize);
						// frame 2 
					doBayesEstimate = !computeHomogeneousAreaStep1(group3d_frame2, sP, nSP,
						threshold, p_imSize);
					for(int i =0 ;i<nB_frame;i++){
						doBayesEstimate = !computeHomogeneousAreaStep1(group4d[i], sP, nSP,
						threshold, p_imSize);
					}
				}
				else {
					doBayesEstimate = !computeHomogeneousAreaStep2(group3dNoisy, group3dBasic,
						sP, nSimP, threshold, p_imSize);
				}
			}

			//! Else, use Bayes' estimate
			if (doBayesEstimate) {
				if (p_params.isFirstStep) {
					computeBayesEstimateStep1(group3d, mat, nInverseFailed, p_params);
					computeBayesEstimateStep1(group3d_frame2, mat, nInverseFailed, p_params);

					for(int i =0;i<nB_frame;i++){
					computeBayesEstimateStep1(group4d[i], mat, nInverseFailed, p_params);
					}

				}
				else {
					computeBayesEstimateStep2(group3dNoisy, group3dBasic, mat, nInverseFailed,
						p_imSize, p_params, nSimP);
					
				}
			}

			//! Aggregation
			if (p_params.isFirstStep) {
				computeAggregationStep1(io_imBasic, weight, mask, group3d, index, p_imSize,
					p_params);
				computeAggregationStep1(io_imBasic1, weight1, mask, group3d_frame2, index1, p_imSize,
					p_params);
					for(int i=0;i<nB_frame;i++){
					computeAggregationStep1(io__imBasic[i][n], weight_4d[i], mask, group4d[i], index_4d[i], p_imSize,p_params);

					}
			}
			else {
				computeAggregationStep2(o_imFinal, weight, mask, group3dBasic, index, p_imSize,
					p_params, nSimP);
			}
		}
	}

	//! Weighted aggregation
	computeWeightedAggregation(i_imNoisy, io_imBasic, o_imFinal, weight, p_params, p_imSize);
	computeWeightedAggregation(i_imNoisy1, io_imBasic1, o_imFinal1, weight1, p_params, p_imSize);
	for(int i=0 ;i<nB_frame;i++){
	computeWeightedAggregation(i__imNoisy[i], io__imBasic[i][n],o_imFinal1,weight_4d[i], p_params, p_imSize);

	}

	if (nInverseFailed > 0 && p_params.verbose) {
		cout << "nInverseFailed = " << nInverseFailed << endl;
	}
	
}

void calcule_histogram(
 	std::vector<std::vector<float>> const& i__im
,	const unsigned p_ij
,	std::vector<float> &Gx
,	std::vector<float> &Gy
,	const unsigned sP		
,	const unsigned width	
, 	const int center_image
,   std::vector<float> &Gradient_Magnitude
,	std::vector<float> &Gradient_Orientation
,	std::vector<float> &hog_histogram
){
for (unsigned p = 0; p < sP; p++) {
				for (unsigned q = 0; q < sP; q++) {
					Gx[p*sP+q] = i__im[center_image][p_ij+p*width+q+1]-i__im[center_image][p_ij + p*width+q-1];
					Gy[p*sP+q] = i__im[center_image][p_ij+p*(width-1)+q]-i__im[center_image][p_ij + p*(width+1)+q];
					// Calculate the Magnitude and Orientation
					Gradient_Magnitude[p*sP+q]= sqrt(pow(Gx[p*sP+q],2)+pow(Gy[p*sP+q],2));
					Gradient_Orientation[p*sP+q]= atan2(Gy[p*sP+q],Gx[p*sP+q])*180/3.1415 ;
					// create histogram
					if(Gradient_Orientation[p*sP+q]>0 && Gradient_Orientation[p*sP+q]<=20){
							hog_histogram[0]=hog_histogram[0]+Gradient_Magnitude[p*sP+q]*(20-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[1]=hog_histogram[1]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q])/20;
					}else if(Gradient_Orientation[p*sP+q]>20 && Gradient_Orientation[p*sP+q]<=40){
							hog_histogram[2]=hog_histogram[2]+Gradient_Magnitude[p*sP+q]*(40-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[3]=hog_histogram[3]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-20)/20;
					}else if(Gradient_Orientation[p*sP+q]>40 && Gradient_Orientation[p*sP+q]<=60){
							hog_histogram[3]=hog_histogram[3]+Gradient_Magnitude[p*sP+q]*(60-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[4]=hog_histogram[4]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-40)/20;
					}else if(Gradient_Orientation[p*sP+q]>60 && Gradient_Orientation[p*sP+q]<=80){
							hog_histogram[4]=hog_histogram[4]+Gradient_Magnitude[p*sP+q]*(80-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[5]=hog_histogram[5]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-60)/20;
					}else if(Gradient_Orientation[p*sP+q]>80 && Gradient_Orientation[p*sP+q]<=100){
							hog_histogram[5]=hog_histogram[5]+Gradient_Magnitude[p*sP+q]*(100-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[6]=hog_histogram[6]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-80)/20;
					}else if(Gradient_Orientation[p*sP+q]>100 && Gradient_Orientation[p*sP+q]<=120){
							hog_histogram[6]=hog_histogram[6]+Gradient_Magnitude[p*sP+q]*(120-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[7]=hog_histogram[7]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-100)/20;
					}else if(Gradient_Orientation[p*sP+q]>120 && Gradient_Orientation[p*sP+q]<=140){
							hog_histogram[7]=hog_histogram[7]+Gradient_Magnitude[p*sP+q]*(140-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[8]=hog_histogram[8]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-120)/20;
					}else if(Gradient_Orientation[p*sP+q]>140 && Gradient_Orientation[p*sP+q]<=160){
							hog_histogram[8]=hog_histogram[8]+Gradient_Magnitude[p*sP+q]*(160-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[9]=hog_histogram[9]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-140)/20;
					}else if(Gradient_Orientation[p*sP+q]>160 && Gradient_Orientation[p*sP+q]<=180){
							hog_histogram[9]=hog_histogram[9]+Gradient_Magnitude[p*sP+q]*(180-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[0]=hog_histogram[0]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-160)/20;
					}		
		}
	}


}






/**
 * @brief Estimate the best similar patches to a reference one.
 *
 * @param i_im: contains the noisy image on which distances are processed;
 * @param o_group3d: will contain values of similar patches;
 * @param o_index: will contain index of similar patches;
 * @param p_ij: index of the reference patch;
 * @param p_imSize: size of the image;
 * @param p_params: see processStep1 for more explanation.
 *
 * @return none.
 **/
void estimateSimilarPatchesStep1(
	std::vector<float> const& i_im
,	std::vector<std::vector<float> > &o_group3d
,	std::vector<unsigned> &o_index
,	const unsigned p_ij
,	const ImageSize &p_imSize
,	const nlbParams &p_params
,   std::vector<std::vector<float> > &o_group3d_frame2
, 	float *u
,	float *v
, 	std::vector<float> const& i_im1
,	std::vector<unsigned> &o_index1
, 	std::vector<std::vector<float>> const& i__im
,	std::vector<std::vector<std::vector<float>>> &o_group4d
, 	std::vector<std::vector<unsigned>> &o_index_4d
, 	int nB_frame
,   float **v_images
,   float **u_images
){
	//! Initialization
	const unsigned sW		= p_params.sizeSearchWindow;
	const unsigned sP		= p_params.sizePatch;
	const unsigned width	= p_imSize.width;
	const unsigned chnls	= p_imSize.nChannels;
	const unsigned wh		= width * p_imSize.height;
	const unsigned ind		= p_ij - (sW - 1) * (width + 1) / 2;
	const unsigned nSimP	= p_params.nSimilarPatches;
	vector<pair<float, unsigned> > distance(sW * sW);
	vector<pair<float, unsigned> > distance1(sW * sW);
	int center_image = (int)nB_frame/2;
	vector<float> Gx(sP*sP),Gx_search(sP*sP);
	vector<float> Gy(sP*sP),Gy_search(sP*sP);
	vector<float> Gradient_Magnitude(sP*sP),Gradient_Magnitude_s(sP*sP) ;
	vector<float> Gradient_Orientation(sP*sP),Gradient_Orientation_s(sP*sP) ;
	vector<float> hog_histogram(9);
	
	// calcule histogram reference patch 
for (unsigned p = 0; p < sP; p++) {
				for (unsigned q = 0; q < sP; q++) {
					Gx[p*sP+q] = i__im[center_image][p_ij+p*width+q+1]-i__im[center_image][p_ij + p*width+q-1];
					Gy[p*sP+q] = i__im[center_image][p_ij+p*(width-1)+q]-i__im[center_image][p_ij + p*(width+1)+q];
					// Calculate the Magnitude and Orientation
					Gradient_Magnitude[p*sP+q]= sqrt(pow(Gx[p*sP+q],2)+pow(Gy[p*sP+q],2));
					Gradient_Orientation[p*sP+q]= atan2(Gy[p*sP+q],Gx[p*sP+q])*180/3.1415 ;
					// create histogram
					if(Gradient_Orientation[p*sP+q]>0 && Gradient_Orientation[p*sP+q]<=20){
							hog_histogram[0]=hog_histogram[0]+Gradient_Magnitude[p*sP+q]*(20-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[1]=hog_histogram[1]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q])/20;
					}else if(Gradient_Orientation[p*sP+q]>20 && Gradient_Orientation[p*sP+q]<=40){
							hog_histogram[2]=hog_histogram[2]+Gradient_Magnitude[p*sP+q]*(40-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[3]=hog_histogram[3]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-20)/20;
					}else if(Gradient_Orientation[p*sP+q]>40 && Gradient_Orientation[p*sP+q]<=60){
							hog_histogram[3]=hog_histogram[3]+Gradient_Magnitude[p*sP+q]*(60-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[4]=hog_histogram[4]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-40)/20;
					}else if(Gradient_Orientation[p*sP+q]>60 && Gradient_Orientation[p*sP+q]<=80){
							hog_histogram[4]=hog_histogram[4]+Gradient_Magnitude[p*sP+q]*(80-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[5]=hog_histogram[5]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-60)/20;
					}else if(Gradient_Orientation[p*sP+q]>80 && Gradient_Orientation[p*sP+q]<=100){
							hog_histogram[5]=hog_histogram[5]+Gradient_Magnitude[p*sP+q]*(100-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[6]=hog_histogram[6]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-80)/20;
					}else if(Gradient_Orientation[p*sP+q]>100 && Gradient_Orientation[p*sP+q]<=120){
							hog_histogram[6]=hog_histogram[6]+Gradient_Magnitude[p*sP+q]*(120-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[7]=hog_histogram[7]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-100)/20;
					}else if(Gradient_Orientation[p*sP+q]>120 && Gradient_Orientation[p*sP+q]<=140){
							hog_histogram[7]=hog_histogram[7]+Gradient_Magnitude[p*sP+q]*(140-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[8]=hog_histogram[8]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-120)/20;
					}else if(Gradient_Orientation[p*sP+q]>140 && Gradient_Orientation[p*sP+q]<=160){
							hog_histogram[8]=hog_histogram[8]+Gradient_Magnitude[p*sP+q]*(160-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[9]=hog_histogram[9]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-140)/20;
					}else if(Gradient_Orientation[p*sP+q]>160 && Gradient_Orientation[p*sP+q]<=180){
							hog_histogram[9]=hog_histogram[9]+Gradient_Magnitude[p*sP+q]*(180-Gradient_Orientation[p*sP+q])/20;
							hog_histogram[0]=hog_histogram[0]+Gradient_Magnitude[p*sP+q]*(Gradient_Orientation[p*sP+q]-160)/20;
					}		
		}
	}
	//cout<<p_ij<<endl;
	//calcule_histogram(i__im,p_ij,Gx,Gx,sP,width,center_image,Gradient_Magnitude,Gradient_Orientation,hog_histogram);
	/*for(int i = 0 ; i<9 ; i++){
		cout<< i  << " : " << hog_histogram[i]<<endl;
	}*/
	//! Compute distance between patches
	for (unsigned i = 0; i < sW; i++) {
		for (unsigned j = 0; j < sW; j++) {
			const unsigned k = i * width + j + ind;
			float diff = 0.f;
			float diff1 = 0.f;
			vector<float> hog_histogram_s(9);
			for (unsigned p = 0; p < sP; p++) {
				for (unsigned q = 0; q < sP; q++) {
					const float tmpValue = i_im[p_ij + p * width + q] - i_im[k + p * width + q];
					const float tmpValue1 = i__im[center_image][p_ij + p * width + q] - i__im[center_image][k + p * width + q];

					//search histogram 
					Gx_search[p*sP+q] = i__im[center_image][k+p*width+q+1]-i__im[center_image][k + p*width+q-1];
					Gy_search[p*sP+q] = i__im[center_image][k+p*(width-1)+q]-i__im[center_image][k + p*(width+1)+q];
					// Calculate the Magnitude and Orientation
					Gradient_Magnitude_s[p*sP+q]= sqrt(pow(Gx_search[p*sP+q],2)+pow(Gy_search[p*sP+q],2));
					Gradient_Orientation_s[p*sP+q]= atan2(Gy_search[p*sP+q],Gx_search[p*sP+q])*180/3.1415 ;
					// create histogram
					if(Gradient_Orientation_s[p*sP+q]>0 && Gradient_Orientation_s[p*sP+q]<=20){
							hog_histogram_s[0]=hog_histogram_s[0]+Gradient_Magnitude_s[p*sP+q]*(20-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[1]=hog_histogram_s[1]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q])/20;
					}else if(Gradient_Orientation_s[p*sP+q]>20 && Gradient_Orientation_s[p*sP+q]<=40){
							hog_histogram_s[2]=hog_histogram_s[2]+Gradient_Magnitude_s[p*sP+q]*(40-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[3]=hog_histogram_s[3]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q]-20)/20;
					}else if(Gradient_Orientation_s[p*sP+q]>40 && Gradient_Orientation_s[p*sP+q]<=60){
							hog_histogram_s[3]=hog_histogram_s[3]+Gradient_Magnitude_s[p*sP+q]*(60-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[4]=hog_histogram_s[4]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q]-40)/20;
					}else if(Gradient_Orientation_s[p*sP+q]>60 && Gradient_Orientation_s[p*sP+q]<=80){
							hog_histogram_s[4]=hog_histogram_s[4]+Gradient_Magnitude_s[p*sP+q]*(80-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[5]=hog_histogram_s[5]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q]-60)/20;
					}else if(Gradient_Orientation_s[p*sP+q]>80 && Gradient_Orientation_s[p*sP+q]<=100){
							hog_histogram_s[5]=hog_histogram_s[5]+Gradient_Magnitude_s[p*sP+q]*(100-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[6]=hog_histogram_s[6]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q]-80)/20;
					}else if(Gradient_Orientation_s[p*sP+q]>100 && Gradient_Orientation_s[p*sP+q]<=120){
							hog_histogram_s[6]=hog_histogram_s[6]+Gradient_Magnitude_s[p*sP+q]*(120-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[7]=hog_histogram_s[7]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q]-100)/20;
					}else if(Gradient_Orientation_s[p*sP+q]>120 && Gradient_Orientation_s[p*sP+q]<=140){
							hog_histogram_s[7]=hog_histogram_s[7]+Gradient_Magnitude_s[p*sP+q]*(140-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[8]=hog_histogram_s[8]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q]-120)/20;
					}else if(Gradient_Orientation_s[p*sP+q]>140 && Gradient_Orientation_s[p*sP+q]<=160){
							hog_histogram_s[8]=hog_histogram_s[8]+Gradient_Magnitude_s[p*sP+q]*(160-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[9]=hog_histogram_s[9]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q]-140)/20;
					}else if(Gradient_Orientation_s[p*sP+q]>160 && Gradient_Orientation_s[p*sP+q]<=180){
							hog_histogram_s[9]=hog_histogram_s[9]+Gradient_Magnitude_s[p*sP+q]*(180-Gradient_Orientation_s[p*sP+q])/20;
							hog_histogram_s[0]=hog_histogram_s[0]+Gradient_Magnitude_s[p*sP+q]*(Gradient_Orientation_s[p*sP+q]-160)/20;
					}		
					//match_distance 
					/*for (int i=1;i<9;i++){
						hog_histogram[i]+=hog_histogram[i-1];
						hog_histogram_s[i]+=hog_histogram_s[i-1];
					}*/
					float  m=0 ;
					for(int i=0 ; i<9;i++){
						//diff+=abs(hog_histogram[i]-hog_histogram_s[i]);
					/*	m=(hog_histogram[i]+hog_histogram_s[i])/2;
						if(m!=0){
							diff=diff+(pow(hog_histogram[i]-m,2))/2;
							//diff = diff + hog_histogram[i]*log(hog_histogram[i]/m)+hog_histogram_s[i]*log(hog_histogram_s[i]/m);
							//diff = diff + hog_histogram[i]*log(hog_histogram[i]/hog_histogram_s[i]);
						}*/
						m=hog_histogram[i]-hog_histogram_s[i];
						diff=diff+m*m;
						diff = sqrt(diff);
						
					}
					
					//diff += tmpValue * tmpValue;
					//diff1 += tmpValue1*tmpValue1;
					diff1=diff;


				}
			}
			//! Save all distances
			distance[i * sW + j] = make_pair(diff, k);
			distance1[i * sW + j] = make_pair(diff1, k);
		}
	}
		//		cout << " a : " <<a<< " b :"<< b <<endl;
	   


	//! Keep only the N2 best similar patches
	partial_sort(distance.begin(), distance.begin() + nSimP, distance.end(), comparaisonFirst);
	partial_sort(distance1.begin(), distance1.begin() + nSimP, distance1.end(), comparaisonFirst);


	//! Register position of patches
	for (unsigned n = 0; n < nSimP; n++) {
		o_index[n] = distance[n].second;
		o_index_4d[center_image][n]=distance1[n].second;
	}
	unsigned position,x_position,y_position;
	unsigned position1,x_position1,y_position1;
	//cout<< nSimP << endl;
	ImageSize imSize2,imSize3;
	imSize2.height=imSize2.width= sP;
	imSize2.wh=sP*sP;
	imSize2.whc=sP*sP*chnls;
	imSize2.nChannels=chnls;
	vector<vector<float>> patch;
	vector<float> image;
	//! Register similar patches into the 3D group
	for (unsigned c = 0; c < chnls; c++) {
		for (unsigned p = 0, k = 0; p < sP; p++) {
			for (unsigned q = 0; q < sP; q++) {
				for (unsigned n = 0; n < nSimP; n++, k++) {
					o_group3d[c][k] = i_im[o_index[n] + p * width + q + c * wh];
					
					//cout<<o_index[n] + p * width + q + c * wh <<endl;
					position = o_index[n] ; //+p * width + q + c * wh;
					//calcule i and j 
					y_position = unsigned(position/(p_imSize.width+1));
					x_position = unsigned(position - (y_position*p_imSize.width));

					float p1[2] = {x_position + u[y_position*p_imSize.width + x_position],y_position + v[y_position * p_imSize.width + x_position]};
				//	float value = bicubic_interpolation_at1(&i_im[0],p1[0],p1[1],p_imSize.width,p_imSize.height,true);
				//  value=value+1;
					o_index1[n]=p_imSize.width*(unsigned(p1[1])-1)+unsigned(p1[0]);
					o_group3d_frame2[c][k] = i_im1[o_index1[n]+ p * width + q + c * wh];
					
					
					o_group4d[center_image][c][k]= i__im[center_image][o_index_4d[center_image][n] + p * width + q + c * wh];
					position1 = o_index_4d[center_image][n];
					for(int i =1 ; i<=(nB_frame-1)/2;i++){
					y_position1 = unsigned(position1/(p_imSize.width+1));
					x_position1 = unsigned(position1- (y_position1*p_imSize.width));
					float p2[2] = {x_position1 + u_images[0][y_position1*p_imSize.width + x_position1],y_position1 + v_images[0][y_position1 * p_imSize.width + x_position1]};
					float p3[2] = {x_position1 + u_images[1][y_position1*p_imSize.width + x_position1],y_position1 + v_images[1][y_position1 * p_imSize.width + x_position1]};
					o_index_4d[center_image+i][n]=p_imSize.width*(unsigned(p2[1])-1)+unsigned(p2[0]);
					o_group4d[center_image+i][c][k]=i__im[center_image+i][o_index_4d[center_image+i][n] + p * width + q + c * wh];

					o_index_4d[center_image-i][n]=p_imSize.width*(unsigned(p3[1])-1)+unsigned(p3[0]);
					o_group4d[center_image-i][c][k]=i__im[center_image-i][o_index_4d[center_image-i][n] + p * width + q + c * wh];
					}			
				}
			}
		}
	
	}
	
    imSize2.height=sP;
	imSize2.width = sP*nSimP;
	imSize2.wh=imSize2.height*imSize2.width;
	imSize2.whc=imSize2.wh*chnls;
	imSize2.nChannels=chnls;
	patch.resize(nSimP);
	image.resize(nSimP*sP*sP+nSimP*sP);
	for (unsigned n = 0; n < nSimP; n++) {
		patch[n].resize(sP*sP);
	for (unsigned p = 0, k = 0; p < sP; p++) {
			for (unsigned q = 0; q < sP; q++,k++) {
				patch[n][k]=i_im[o_index[n] + p * width + q ];
			}
	}


	string location = "patch/patch"+ to_string(n);
/*	if (saveImage(&location[0], patch[n], imSize2, 0.f, 255.f) != EXIT_SUCCESS) {
        return ;
    }*/
	}
	unsigned k =0;
	for (unsigned p = 0; p < sP; p++) {
		for (unsigned n = 0; n < nSimP; n++) {
			for (unsigned q = 0; q < sP; q++,k++) {
				image[k]= patch[n][q +sP*p];
				
			}
			
			//image[k]=255;
		//	k++;
			
	}
	
	}

	vector<float> histograme,image_histograme;
    histograme.resize(256);
     for (unsigned i = 0; i < sP*sP;i++){
		 for(unsigned j =0 ; j<nSimP;j++)
        histograme[abs(int(patch[j][i]))]++;
}
	unsigned plus_grand  = 0;
    for(int i;i<histograme.size();i++){
        if(plus_grand<histograme[i]){
            plus_grand=histograme[i];
        }
    }

	image_histograme.resize(256*plus_grand);
    for(int i = 0 ; i<256;i++){
        for(int j=0; j<histograme[i];j++){
            image_histograme[j+i*plus_grand]=255;
        }
    }
	imSize3.height=256;
    imSize3.width=plus_grand;
    imSize3.nChannels=1;
    imSize3.wh=imSize3.width*imSize3.height;
    imSize3.whc=imSize3.wh*imSize3.nChannels;
    if (saveImage("patch_histograme", image_histograme, imSize3, 0.f, 255.f) != EXIT_SUCCESS) {
		return ;
    }
	if (saveImage("image_patche", image, imSize2, 0.f, 255.f) != EXIT_SUCCESS) {
        return ;
    }
}

/**
 * @brief Keep from all near patches the similar ones to the reference patch for the second step.
 *
 * @param i_imNoisy: contains the original noisy image;
 * @param i_imBasic: contains the basic estimation;
 * @param o_group3dNoisy: will contain similar patches for all channels of i_imNoisy;
 * @param o_group3dBasic: will contain similar patches for all channels of i_imBasic;
 * @param o_index: will contain index of similar patches;
 * @param p_ij: index of the reference patch;
 * @param p_imSize: size of images;
 * @param p_params: see processStep2 for more explanations.
 *
 * @return number of similar patches kept.
 **/
unsigned estimateSimilarPatchesStep2(
	std::vector<float> const& i_imNoisy
,	std::vector<float> const& i_imBasic
,	std::vector<float> &o_group3dNoisy
,	std::vector<float> &o_group3dBasic
,	std::vector<unsigned> &o_index
,	const unsigned p_ij
,	const ImageSize &p_imSize
,	const nlbParams &p_params
){
	//! Initialization
	const unsigned width	= p_imSize.width;
	const unsigned chnls	= p_imSize.nChannels;
	const unsigned wh		= width * p_imSize.height;
	const unsigned sP		= p_params.sizePatch;
	const unsigned sW		= p_params.sizeSearchWindow;
	const unsigned ind		= p_ij - (sW - 1) * (width + 1) / 2;
	vector<pair<float, unsigned> > distance(sW * sW);

	//! Compute distance between patches
	for (unsigned i = 0; i < sW; i++) {
		for (unsigned j = 0; j < sW; j++) {
			const unsigned k = i * width + j + ind;
			float diff = 0.0f;

			for (unsigned c = 0; c < chnls; c++) {
				const unsigned dc = c * wh;
				for (unsigned p = 0; p < sP; p++) {
					for (unsigned q = 0; q < sP; q++) {
						const float tmpValue = i_imBasic[dc + p_ij + p * width + q]
											- i_imBasic[dc + k + p * width + q];
						diff += tmpValue * tmpValue;
					}
				}
			}

			//! Save all distances
			distance[i * sW + j] = make_pair(diff, k);
		}
	}

	//! Keep only the nSimilarPatches best similar patches
	partial_sort(distance.begin(), distance.begin() + p_params.nSimilarPatches, distance.end(),
		comparaisonFirst);

	//! Save index of similar patches
	const float threshold = (p_params.tau > distance[p_params.nSimilarPatches - 1].first ?
							p_params.tau : distance[p_params.nSimilarPatches - 1].first);
	unsigned nSimP = 0;

	//! Register position of similar patches
	for (unsigned n = 0; n < distance.size(); n++) {
		if (distance[n].first < threshold) {
			o_index[nSimP++] = distance[n].second;
		}
	}

	//! Save similar patches into 3D groups
	for (unsigned c = 0, k = 0; c < chnls; c++) {
		for (unsigned p = 0; p < sP; p++) {
			for (unsigned q = 0; q < sP; q++) {
				for (unsigned n = 0; n < nSimP; n++, k++) {
					o_group3dNoisy[k] = i_imNoisy[c * wh + o_index[n] + p * width + q];
					o_group3dBasic[k] = i_imBasic[c * wh + o_index[n] + p * width + q];
				}
			}
		}
	}

	return nSimP;
}

/**
 * @brief Detect if we are in an homogeneous area. In this case, compute the mean.
 *
 * @param io_group3d: contains for each channels values of similar patches. If an homogeneous area
 *			is detected, will contain the average of all pixels in similar patches;
 * @param p_sP2: size of each patch (sP x sP);
 * @param p_nSimP: number of similar patches;
 * @param p_threshold: threshold below which an area is declared homogeneous;
 * @param p_doLinearRegression: if true, apply a linear regression to average value of pixels;
 * @param p_imSize: size of the image.
 *
 * @return 1 if an homogeneous area is detected, 0 otherwise.
 **/
int computeHomogeneousAreaStep1(
	std::vector<std::vector<float> > &io_group3d
,	const unsigned p_sP
,	const unsigned p_nSimP
,	const float p_threshold
,	const ImageSize &p_imSize
){
	//! Initialization
	const unsigned N = p_sP * p_sP * p_nSimP;

	//! Compute the standard deviation of the set of patches
	float stdDev = 0.f;
	for (unsigned c = 0; c < p_imSize.nChannels; c++) {
		stdDev += computeStdDeviation(io_group3d[c], p_sP * p_sP, p_nSimP, 1);
	}

	//! If we are in an homogeneous area
	if (stdDev < p_threshold) {
		for (unsigned c = 0; c < p_imSize.nChannels; c++) {
            float mean = 0.f;

            for (unsigned k = 0; k < N; k++) {
                mean += io_group3d[c][k];
            }

            mean /= (float) N;

            for (unsigned k = 0; k < N; k++) {
                io_group3d[c][k] = mean;
            }
        }
		return 1;
	}
	else {
		return 0;
	}
}

/**
 * @brief Detect if we are in an homogeneous area. In this case, compute the mean.
 *
 * @param io_group3dNoisy: contains values of similar patches for the noisy image;
 * @param io_group3dBasic: contains values of similar patches for the basic image. If an homogeneous
 *		area is detected, will contain the average of all pixels in similar patches;
 * @param p_sP2: size of each patch (sP x sP);
 * @param p_nSimP: number of similar patches;
 * @param p_threshold: threshold below which an area is declared homogeneous;
 * @param p_imSize: size of the image.
 *
 * @return 1 if an homogeneous area is detected, 0 otherwise.
 **/
int computeHomogeneousAreaStep2(
	std::vector<float> const& i_group3dNoisy
,	std::vector<float> &io_group3dBasic
,	const unsigned p_sP
,	const unsigned p_nSimP
,	const float p_threshold
,	const ImageSize &p_imSize
){
	//! Parameters
	const unsigned sP2	= p_sP * p_sP;
	const unsigned sPC = sP2 * p_imSize.nChannels;

	//! Compute the standard deviation of the set of patches
	const float stdDev = computeStdDeviation(i_group3dNoisy, sP2, p_nSimP, p_imSize.nChannels);

	//! If we are in an homogeneous area
	if (stdDev < p_threshold) {
		for (unsigned c = 0; c < p_imSize.nChannels; c++) {
            float mean = 0.f;

            for (unsigned n = 0; n < p_nSimP; n++) {
                for (unsigned k = 0; k < sP2; k++) {
                    mean += io_group3dBasic[n * sPC + c * sP2 + k];
                }
            }

            mean /= float(sP2 * p_nSimP);

            for (unsigned n = 0; n < p_nSimP; n++) {
                for (unsigned k = 0; k < sP2; k++) {
                    io_group3dBasic[n * sPC + c * sP2 + k] = mean;
                }
            }
		}
		return 1;
	}
	else {
		return 0;
	}
}

/**
 * @brief Compute the Bayes estimation.
 *
 * @param io_group3d: contains all similar patches. Will contain estimates for all similar patches;
 * @param i_mat: contains :
 *		- group3dTranspose: allocated memory. Used to contain the transpose of io_group3dNoisy;
 *		- baricenter: allocated memory. Used to contain the baricenter of io_group3dBasic;
 *		- covMat: allocated memory. Used to contain the covariance matrix of the 3D group;
 *		- covMatTmp: allocated memory. Used to process the Bayes estimate;
 *		- tmpMat: allocated memory. Used to process the Bayes estimate;
 * @param io_nInverseFailed: update the number of failed matrix inversion;
 * @param p_params: see processStep1 for more explanation.
 *
 * @return none.
 **/
 void computeBayesEstimateStep1(
	std::vector<std::vector<float> > &io_group3d
,	matParams &i_mat
,	unsigned &io_nInverseFailed
,	nlbParams &p_params
){
	//! Parameters
	const unsigned chnls = io_group3d.size();
	const unsigned nSimP = p_params.nSimilarPatches;
	const unsigned sP2   = p_params.sizePatch * p_params.sizePatch;
	const float valDiag  = p_params.beta * p_params.sigma * p_params.sigma;

	//! Bayes estimate
	for (unsigned c = 0; c < chnls; c++) {

	    //! Center data around the baricenter
		centerData(io_group3d[c], i_mat.baricenter, nSimP, sP2);

		//! Compute the covariance matrix of the set of similar patches
		covarianceMatrix(io_group3d[c], i_mat.covMat, nSimP, sP2);

		//! Bayes' Filtering
		if (inverseMatrix(i_mat.covMat, sP2) == EXIT_SUCCESS) {
            productMatrix(i_mat.group3dTranspose, i_mat.covMat, io_group3d[c], sP2, sP2, nSimP);
            for (unsigned k = 0; k < sP2 * nSimP; k++) {
                io_group3d[c][k] -= valDiag * i_mat.group3dTranspose[k];
            }
		}
		else {
			io_nInverseFailed++;
		}

		//! Add baricenter
		for (unsigned j = 0, k = 0; j < sP2; j++) {
			for (unsigned i = 0; i < nSimP; i++, k++) {
			    io_group3d[c][k] += i_mat.baricenter[j];
			}
		}
	}

}

/**
 * @brief Compute the Bayes estimation.
 *
 * @param i_group3dNoisy: contains all similar patches in the noisy image;
 * @param io_group3dBasic: contains all similar patches in the basic image. Will contain estimates
 *			for all similar patches;
 * @param i_mat: contains :
 *		- group3dTranspose: allocated memory. Used to contain the transpose of io_group3dNoisy;
 *		- baricenter: allocated memory. Used to contain the baricenter of io_group3dBasic;
 *		- covMat: allocated memory. Used to contain the covariance matrix of the 3D group;
 *		- covMatTmp: allocated memory. Used to process the Bayes estimate;
 *		- tmpMat: allocated memory. Used to process the Bayes estimate;
 * @param io_nInverseFailed: update the number of failed matrix inversion;
 * @param p_imSize: size of the image;
 * @param p_params: see processStep2 for more explanations;
 * @param p_nSimP: number of similar patches.
 *
 * @return none.
 **/
void computeBayesEstimateStep2(
	std::vector<float> &i_group3dNoisy
,	std::vector<float> &io_group3dBasic
,	matParams &i_mat
,	unsigned &io_nInverseFailed
,	const ImageSize &p_imSize
,	nlbParams p_params
,	const unsigned p_nSimP
){
	//! Parameters initialization
	const float diagVal = p_params.beta * p_params.sigma * p_params.sigma;
	const unsigned sPC  = p_params.sizePatch * p_params.sizePatch * p_imSize.nChannels;

	//! Center 3D groups around their baricenter
	centerData(io_group3dBasic, i_mat.baricenter, p_nSimP, sPC);
	centerData(i_group3dNoisy, i_mat.baricenter, p_nSimP, sPC);

	//! Compute the covariance matrix of the set of similar patches
	covarianceMatrix(io_group3dBasic, i_mat.covMat, p_nSimP, sPC);

	//! Bayes' Filtering
    for (unsigned k = 0; k < sPC; k++) {
        i_mat.covMat[k * sPC + k] += diagVal;
    }

	//! Compute the estimate
	if (inverseMatrix(i_mat.covMat, sPC) == EXIT_SUCCESS) {
        productMatrix(io_group3dBasic, i_mat.covMat, i_group3dNoisy, sPC, sPC, p_nSimP);
        for (unsigned k = 0; k < sPC * p_nSimP; k++) {
            io_group3dBasic[k] = i_group3dNoisy[k] - diagVal * io_group3dBasic[k];
        }
	}
	else {
		io_nInverseFailed++;
	}

	//! Add baricenter
	for (unsigned j = 0, k = 0; j < sPC; j++) {
		for (unsigned i = 0; i < p_nSimP; i++, k++) {
			io_group3dBasic[k] += i_mat.baricenter[j];
		}
	}
}

/**
 * @brief Aggregate estimates of all similar patches contained in the 3D group.
 *
 * @param io_im: update the image with estimate values;
 * @param io_weight: update corresponding weight, used later in the weighted aggregation;
 * @param io_mask: update values of mask: set to true the index of an used patch;
 * @param i_group3d: contains estimated values of all similar patches in the 3D group;
 * @param i_index: contains index of all similar patches contained in i_group3d;
 * @param p_imSize: size of io_im;
 * @param p_params: see processStep1 for more explanation.
 *
 * @return none.
 **/
void computeAggregationStep1(
	std::vector<float> &io_im
,	std::vector<float> &io_weight
,	std::vector<bool> &io_mask
,	std::vector<std::vector<float> > const& i_group3d
,	std::vector<unsigned> const& i_index
,	const ImageSize &p_imSize
,	const nlbParams &p_params
){
	//! Parameters initializations
	const unsigned chnls	= p_imSize.nChannels;
	const unsigned width	= p_imSize.width;
	const unsigned height	= p_imSize.height;
	const unsigned sP		= p_params.sizePatch;
	const unsigned nSimP	= p_params.nSimilarPatches;

	//! Aggregate estimates
	for (unsigned n = 0; n < nSimP; n++) {
		const unsigned ind = i_index[n];
		for (unsigned c = 0; c < chnls; c++) {
			const unsigned ij = ind + c * width * height;
			for (unsigned p = 0; p < sP; p++) {
				for (unsigned q = 0; q < sP; q++) {
					io_im[ij + p * width + q] += i_group3d[c][(p * sP + q) * nSimP + n];
					io_weight[ij + p * width + q]++;
				}
			}
		}

		//! Use Paste Trick
		io_mask[ind] = false;

		if (p_params.doPasteBoost) {
			io_mask[ind - width ] = false;
			io_mask[ind + width ] = false;
			io_mask[ind - 1		] = false;
			io_mask[ind + 1		] = false;
		}
	}
}

/**
 * @brief Aggregate estimates of all similar patches contained in the 3D group.
 *
 * @param io_im: update the image with estimate values;
 * @param io_weight: update corresponding weight, used later in the weighted aggregation;
 * @param io_mask: update values of mask: set to true the index of an used patch;
 * @param i_group3d: contains estimated values of all similar patches in the 3D group;
 * @param i_index: contains index of all similar patches contained in i_group3d;
 * @param p_imSize: size of io_im;
 * @param p_params: see processStep2 for more explanation;
 * @param p_nSimP: number of similar patches.
 *
 * @return none.
 **/
void computeAggregationStep2(
	std::vector<float> &io_im
,	std::vector<float> &io_weight
,	std::vector<bool> &io_mask
,	std::vector<float> const& i_group3d
,	std::vector<unsigned> const& i_index
,	const ImageSize &p_imSize
,	const nlbParams &p_params
,	const unsigned p_nSimP
){
	//! Parameters initializations
	const unsigned chnls	= p_imSize.nChannels;
	const unsigned width	= p_imSize.width;
	const unsigned wh		= width * p_imSize.height;
	const unsigned sP		= p_params.sizePatch;

	//! Aggregate estimates
	for (unsigned n = 0; n < p_nSimP; n++) {
		const unsigned ind = i_index[n];
		for (unsigned c = 0, k = 0; c < chnls; c++) {
			const unsigned ij = ind + c * wh;
			for (unsigned p = 0; p < sP; p++) {
				for (unsigned q = 0; q < sP; q++, k++) {
					io_im[ij + p * width + q] += i_group3d[k * p_nSimP + n];
					io_weight[ij + p * width + q]++;
				}
			}
		}

		//! Apply Paste Trick
		io_mask[ind] = false;

		if (p_params.doPasteBoost) {
			io_mask[ind - width ] = false;
			io_mask[ind + width ] = false;
			io_mask[ind - 1     ] = false;
			io_mask[ind + 1     ] = false;
		}
	}
}

/**
 * @brief Compute the final weighted aggregation.
 *
 * i_imReference: image of reference, when the weight if null;
 * io_imResult: will contain the final image;
 * i_weight: associated weight for each estimate of pixels.
 *
 * @return : none.
 **/
void computeWeightedAggregation(
	std::vector<float> const& i_imNoisy
,	std::vector<float> &io_imBasic
,	std::vector<float> &io_imFinal
,	std::vector<float> const& i_weight
,	const nlbParams &p_params
,	const ImageSize &p_imSize
){
	for (unsigned c = 0, k = 0; c < p_imSize.nChannels; c++) {
           
		for (unsigned ij = 0; ij < p_imSize.wh; ij++, k++) {

			//! To avoid weighting problem (particularly near boundaries of the image)
			if (i_weight[k] > 0.f) {
				if (p_params.isFirstStep) {
					io_imBasic[k] /= i_weight[k];
					
				}
				else {
					
					io_imFinal[k] /= i_weight[k];
				}
			}
			else {
				if (p_params.isFirstStep) {
					io_imBasic[k] = i_imNoisy[k];
					
				}
				else {
					io_imFinal[k] = io_imBasic[k];
				}
			}
		}
		
	}
}
